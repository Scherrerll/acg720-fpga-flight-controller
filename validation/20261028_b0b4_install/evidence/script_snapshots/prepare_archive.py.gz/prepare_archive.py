"""Read only named, completed install artifacts; write additive local evidence only."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re

REPO = Path(__file__).resolve().parents[3]
RAW = REPO / 'out/b0b4_install_20261028'
INSTALL = REPO / 'validation/20261028_b0b4_install'
DEST = INSTALL / 'evidence'
AUDIT = Path(__file__).resolve().parent


def require(ok, reason):
    if not ok: raise ValueError(reason)


def digest(data): return hashlib.sha256(data).hexdigest()


def permitted(path):
    # Filter names before reading/stat/hash. No credential files are inspected.
    for part in path.parts:
        name = part.lower()
        require(not (name == '.env' or name.startswith('.env.') or name.endswith('.env') or
                     name.endswith(' .env') or name == 'deployment.env' or
                     any(word in name for word in ('credential', 'secret', 'token')) or
                     name.endswith(('.pem', '.key', '.pfx', '.p12'))), 'Forbidden sensitive filename')
    require(path.is_relative_to(REPO), 'Source escapes repository')
    require(not any(part.lower() in ('ground', 'wire', 'b0b2') for part in path.relative_to(REPO).parts), 'Excluded source family')


def read(path):
    path = path.resolve(); permitted(path)
    require(path.is_file() and not path.is_symlink(), 'Missing/symlinked input: '+str(path))
    before = path.stat(); data = path.read_bytes(); after = path.stat()
    require((before.st_size,before.st_mtime_ns) == (after.st_size,after.st_mtime_ns), 'Growing input: '+str(path))
    return data


def obj(path): return json.loads(read(path).decode('utf-8-sig'))


def normal_zero(value):
    return value.get('normal_wait_return') is True and type(value.get('actual_p_wait')) is int and value['actual_p_wait'] == 0


selected = []


def add(path, relative, role):
    path = path.resolve(); permitted(path)
    require(path not in [p for p,_,_ in selected], 'Duplicate source selection')
    selected.append((path, Path(relative), role))


def stage(name, labels, extra):
    directory = RAW/name
    expected = {label+suffix for label in labels for suffix in ('_process.json','_exit.json','_stdout.log','_stderr.log')} | set(extra)
    # No broad recursion. Unknown files are rejected rather than swept into archive.
    actual = {p.name for p in directory.iterdir() if p.is_file()}
    require(actual == expected, 'Stage whitelist differs: '+name+' '+str(actual ^ expected))
    for filename in sorted(expected): add(directory/filename, 'runtime/'+name+'/'+filename, 'completed_stage')


stage('sram_20261027T225302_793263Z',
      ['qualification','01_identity_before_cables','01_identity_before','02_B0B4_sram_cables','02_B0B4_sram','04_identity_B0B4_cables','04_identity_B0B4'],
      ['stage_report.json','initial_stopped.json','01_identity_before_stopped.json','02_B0B4_sram_stopped.json','03_sram_healthy.json','04_identity_B0B4_stopped.json'])
stage('sram_completion_20261027T225728_816894Z',
      ['01_current_B4_identity_cables','01_current_B4_identity'],
      ['stage_report.json','01_current_B4_identity_stopped.json','02_current_B4_health.json','03_fresh_B4_default_GET.json'])
stage('flash_20261027T225901_092572Z',
      ['qualification']+[label+suffix for label in ['01_before_flash_B4','04_B0B4_program_verify','05_B0B4_reload','07_B0B4_identity','08_B0B4_independent_verify','09_B0B4_final_reload','11_B0B4_final_identity'] for suffix in ('_cables','')],
      ['stage_report.json','01_before_flash_B4_stopped.json','02_current_sram_health.json','03_before_flash_default_GET.json','04_B0B4_program_verify_stopped.json','05_B0B4_reload_reload_boundary.json','06_B0B4_stopped_health.json','07_B0B4_identity_stopped.json','08_B0B4_independent_verify_stopped.json','09_B0B4_final_reload_reload_boundary.json','10_B0B4_final_health.json','11_B0B4_final_identity_stopped.json','12_final_default_GET.json'])
for name in ['root_completion_20261027T225728_627518Z','root_flash_20261027T225900_901379Z']:
    for filename in ['process.json','exit.json','stdout.log','stderr.log']:
        add(RAW/name/filename, 'runtime/'+name+'/'+filename, 'actual_root_capture')
add(RAW/'sram_original_root_observed_exit.json','runtime/sram_original_root_observed_exit.json','observed_tool_root1_not_new_popen_wait')
for name in ['offline_boundary_20261027T225104_920466Z','offline_completion_20261027T225631_295608Z','offline_flash_20261027T225259_992965Z','offline_flash_retry02_20261027T225334_571971Z','offline_flash_retry03_20261027T225745_403633Z']:
    for filename in ['RESULT.json','stdout.log','stderr.log']:
        add(RAW/name/filename,'offline_tests/'+name+'/'+filename,'offline_mock_test')
for filename in ['BINDING_RECHECK.json','stage_report.json']:
    add(RAW/'offline_flash_bind_20261027T225759_529739Z'/filename,'offline_tests/offline_flash_bind_20261027T225759_529739Z/'+filename,'offline_binding_recheck')
for filename in ['bench_b0b4.py','test_bench_b0b4.py','sram_completion_b0b4.py','test_sram_completion_b0b4.py','flash_b0b4.py','test_flash_b0b4.py','run_stage_once.py']:
    add(INSTALL/'scripts'/filename,'script_snapshots/'+filename,'executed_or_tested_script_snapshot')
for revision in ['flash_revision01','flash_revision02']:
    for filename in ['flash_b0b4.py','test_flash_b0b4.py','MANIFEST.json']:
        add(INSTALL/'prepared_revisions'/revision/filename,'script_history/'+revision+'/'+filename,'historical_script_snapshot')
add(Path(__file__),'script_snapshots/prepare_archive.py','archiver_source_snapshot')

# Verify terminal facts without altering any original record or inventing a wait.
original_path = RAW/'sram_20261027T225302_793263Z/stage_report.json'
original = obj(original_path); observed = obj(RAW/'sram_original_root_observed_exit.json')
require(original['passed'] is False and original['error'] == 'ValueError: Same-group telemetry required' and original['sram_written'] is True, 'Original failure fact differs')
require(observed['schema'] == 'b0b4.observed-tool-exit.v1' and observed['actual_p_wait'] == 1 and observed['directly_captured_root_stdout_file'] is False and observed['original_stage_report_sha256'] == digest(read(original_path)), 'Observed original root1 fact differs')
completion_path = RAW/'sram_completion_20261027T225728_816894Z/stage_report.json'
flash_path = RAW/'flash_20261027T225901_092572Z/stage_report.json'
completion = obj(completion_path); flash = obj(flash_path)
require(completion['passed'] is True and completion['additional_sram_write'] is False, 'Completion fact differs')
require(flash['passed'] is True and flash['flash_contents_certified'] is True and flash['independent_flash_verify_passed'] is True and flash['physical_cold_boot_verified'] is False and flash['flight_ready'] is False, 'Flash fact differs')
for name, report_path in [('root_completion_20261027T225728_627518Z',completion_path),('root_flash_20261027T225900_901379Z',flash_path)]:
    root = obj(RAW/name/'exit.json')
    require(normal_zero(root) and root['stage_report_sha256'] == digest(read(report_path)), 'Actual root0 binding differs')
    for stream in ('stdout','stderr'):
        require(root[stream+'_sha256'] == digest(read(RAW/name/(stream+'.log'))), 'Root captured log changed')

require(not DEST.exists(), 'Evidence destination exists; no overwrite')
DEST.mkdir(parents=True)
entries=[]
for source, relative, role in sorted(selected,key=lambda item:item[1].as_posix()):
    data=read(source); raw_sha=digest(data)
    compressed=len(data)>=8192
    if compressed:
        buffer=io.BytesIO()
        with gzip.GzipFile(fileobj=buffer,mode='wb',filename='',mtime=0,compresslevel=9) as stream: stream.write(data)
        archived=buffer.getvalue(); relative=Path(relative.as_posix()+'.gz')
        require(gzip.decompress(archived)==data,'Compression roundtrip differs')
    else: archived=data
    target=DEST/relative; target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(archived)
    stored=target.read_bytes()
    require(stored==archived and digest(gzip.decompress(stored) if compressed else stored)==raw_sha,'Written archive differs')
    entries.append(dict(original_path=str(source),original_repository_path=source.relative_to(REPO).as_posix(),
                        original_sha256=raw_sha,original_bytes=len(data),archive_path=relative.as_posix(),
                        archive_sha256=digest(stored),archive_bytes=len(stored),encoding='gzip-mtime0-no-filename' if compressed else 'identity',
                        decompressed_sha256=raw_sha,decompressed_bytes=len(data),role=role))
for entry in entries:
    require(digest(read(Path(entry['original_path'])))==entry['original_sha256'],'Original changed after archive')

script_hashes={entry['original_sha256'] for entry in entries if entry['original_repository_path'].endswith('.py')}
for name in ['offline_boundary_20261027T225104_920466Z','offline_completion_20261027T225631_295608Z','offline_flash_20261027T225259_992965Z','offline_flash_retry02_20261027T225334_571971Z','offline_flash_retry03_20261027T225745_403633Z']:
    result=obj(RAW/name/'RESULT.json')
    require(normal_zero(result) and result['script_sha256'] in script_hashes and result['test_sha256'] in script_hashes,'Offline run lacks actual zero/script snapshot')

index=dict(schema='b0b4.install-archive.partial.v1',partial=True,cold_pending=True,physical_cold_boot_verified=False,flight_ready=False,
           scope='Named completed installation and offline test records only; raw stage bytes preserved. No ground recorder logs/wire, secrets or bitstream copies.',
           count=len(entries),original_total_bytes=sum(e['original_bytes'] for e in entries),archive_payload_bytes=sum(e['archive_bytes'] for e in entries),
           gzip_count=sum(e['encoding'].startswith('gzip') for e in entries),files=entries,
           historical_outcomes=dict(original_sram_stage_passed=False,original_sram_error=original['error'],original_root_actual_p_wait=1,
                                    original_root_evidence_kind='Observed completed tool/PowerShell LASTEXITCODE; no directly captured root stdout and no newly executed Popen wait',
                                    completion_passed=True,completion_actual_root_p_wait=0,additional_sram_write=False,
                                    flash_passed=True,flash_actual_root_p_wait=0,independent_flash_verify_passed=True),
           existing_qualified_release=dict(bitstream_path='firmware/B0B4/release/acg720_ano_port.fs',expected_sha256='199bc466f8a8fe18e891600d18161babcea9c2495eee8d307dac62ac8646c610',
                                           manifest_path='firmware/B0B4/release_manifest.json',expected_manifest_sha256='c8e03412ff44cbe929f5d8ce6fed6eb3c61078a2028df466a340a61894893a2d',copied=False),
           exclusions=dict(root_files=['ground_stdout.log','ground_stderr.log','initial_telemetry.json','read_target_once.py','readonly_cable.json','readonly_cable.stdout','readonly_cable.stderr','readonly_identity_preflight.json','readonly_identity.json','readonly_identity.stdout','readonly_identity.stderr','readonly_target.json','session.json'],
                           families=['all ground recorder directories and original wireless/serial streams','offline_cold and any not-yet-final cold observation','all .env/environment/credential/private-key names','unrelated B0B2 copy99 proof.zip','all other out files not explicitly whitelisted'],
                           excluded_wire_or_ground_log_content_read=False),all_original_hashes_rechecked_unchanged=True,
           compression=dict(format='gzip',mtime=0,filename='',level=9,each_written_payload_roundtrip_checked=True))
index_path=DEST/'ARCHIVE_INDEX.partial.json'
with index_path.open('x',encoding='utf-8',newline='\n') as stream: stream.write(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
summary=dict(passed=True,index_path=str(index_path),index_sha256=digest(index_path.read_bytes()),count=len(entries),original_total_bytes=index['original_total_bytes'],
             archive_payload_bytes=index['archive_payload_bytes'],index_bytes=index_path.stat().st_size,gzip_count=index['gzip_count'],cold_pending=True,flight_ready=False,
             excluded_raw_ground_wire=True,hardware_accessed=False,http_accessed=False,git_accessed=False)
with (AUDIT/'ARCHIVE_VALIDATION.json').open('x',encoding='utf-8') as stream: stream.write(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
